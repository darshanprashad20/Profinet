from pnio_dcp import DCP, pnio_dcp
ip = "127.0.0.1"
dcp = pnio_dcp.DCP(ip)

identified_devices = dcp.identify_all()

mac_address = "02:00:00:00:00:00"
device = dcp.identify(mac_address)

def discover_profinet_devices():
    # Initialize the PROFINET DCP socket
    with PNioDCPSocket() as dcp_socket:
        print("Sending discovery request...")

        # Send a discovery request to find PROFINET devices on the network
        devices = dcp_socket.discovery()

        if devices:
            for device in devices:
                print(f"Device Name: {device.device_name}")
                print(f"MAC Address: {device.mac_address}")
                print(f"IP Address: {device.ip_address}\n")
        else:
            print("No PROFINET devices found.")


if __name__ == "__main__":
    discover_profinet_devices()
