# Client Code - Simulated Device using profi-dcp
from profi_dcp import DCPManager
import time


def run_simulated_device():
    dcp_manager = DCPManager()
    device_name = "Simulated_Profinet_Device"
    print(f"Simulating PROFINET device: {device_name}")

    while True:
        # Simulate device responding to DCP discovery requests
        print(f"{device_name} is running and waiting for discovery...")
        time.sleep(10)


if __name__ == "__main__":
    run_simulated_device()
